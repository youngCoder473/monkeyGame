//Global Variables

var background,score,obstacleGroup,backImage2,bananaImage,backImage,monkey,monkeyImage,obstacleImage,obstacle,backImage2,ground,bananaGroup,banana,obstacleImage,hit,gameState;
var lifeline;


function preload(){
  monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
 backImage=loadImage("jungle.jpg");
  obstacleImage=loadImage("stone.png");
  bananaImage=loadImage("Banana.png")
}


function setup() {
  createCanvas(600,300);
   score=0;
  hit=0
  gameState=1
 backImage2=createSprite(0,0,600,10);
  backImage2.scale=1.5;
  backImage2.addImage("jungle.jpg",backImage);
  backImage2.velocityX=-4;
  
  monkey=createSprite(75,200,10,10);
  monkey.scale=0.05;
  monkey.addAnimation("monkey.walking",monkeyImage);
  
  ground=createSprite(300,275,600,10);
  ground.visible=false;
  bananaGroup=createGroup();
  obstacleGroup=createGroup();
  lifeline=3;
}


function draw(){
   background(255);
  if(gameState==1){
  if(keyDown("space")&&monkey.y>=224){
     monkey.velocityY=-25;
     }
  if(backImage2.x<0){
    backImage2.x=backImage2 .width/2;
     }
  monkey.velocityY=monkey.velocityY+2
  bananaFunction();
  obstacleFunction();
    if(monkey.isTouching(obstacleGroup)){
      lifeline=lifeline-1;
      obstacleGroup.destroyEach();
      bananaGroup.destroyEach();
      monkey.scale = 0.1;
      gameState = -1;
      }
    if(lifeline==0){
      gameState=0;
    }
  }
  
  if(gameState==0){
    backImage2.velocityX=0
    monkey.destroy();
    bananaGroup.destroyEach();
    obstacleGroup.destroyEach();
    backImage2.velocityX=0;
  }
  
   

  monkey.collide(ground);
  drawSprites();  
  if(gameState == -1){
     text("Press Space to continue",200,200);  
      if(backImage2.x<0){
    backImage2.x=backImage2 .width/2;
     }
  }
 if(gameState ==-1 && keyDown("space")){
   gameState=1;
 }
  
  fill("black");
  textSize(30);
  text("Lifeline="+lifeline,100,50);
  text("Score="+score,245,50);
  
  switch(score){
    case 10: monkey.scale=0.06
      break;
      
    case 20: monkey.scale=0.07
      break;
      
    case 30: monkey.scale=0.08
      break;
      
    case 40: monkey.scale=0.09
      break;
      
    case 50: monkey.scale=0.10
      break;
      
     case 60: monkey.scale=0.11
      break;
    
    case 70: monkey.scale=0.12
      break;
      
     case 80: monkey.scale=0.13
      break;
      
    case 90: monkey.scale=0.14
      break;
    
    case 100: monkey.scale=0.15
      break;
  }
  }

function bananaFunction(){
    if(frameCount%80==0){
    banana=createSprite(650,100,10,10);
     banana.velocityX=-8;
    banana.y=random(250,75);
    banana.scale=0.06;
    banana.addImage("monkey.food",bananaImage);
    bananaGroup.add(banana);
  }
   if(monkey.isTouching(bananaGroup)){
     banana.destroy();
    score++;
     }
}
function obstacleFunction(){
  if(frameCount%100==0){
    obstacle=createSprite(650,250,10,10)
    obstacle.velocityX=-11;
    obstacle.addImage("stone",obstacleImage)  
    obstacle.scale=0.15;
    console.log(obstacle.x);
    obstacleGroup.add(obstacle);
  }
 
}
